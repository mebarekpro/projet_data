from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.service import Service
from webdriver_manager.firefox import GeckoDriverManager
import time
import re
import datetime

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
import tkinter as tk
from tkinter import simpledialog
from selenium.common.exceptions import TimeoutException
from tkinter import messagebox

#prise de coordonnées






#page de rdv script 
driver = webdriver.Firefox(service=Service(executable_path=GeckoDriverManager().install()))



driver.get("https://tunisia.blsspainvisa.com/book_appointment.php")






# Créer une fenêtre tkinter
fenetre = tk.Tk()

# Définir les dimensions de la fenêtre
fenetre.geometry("300x200")

# Définir le texte à afficher dans la fenêtre
message = "Cliquez sur le bouton pour continuer."

# Créer un widget Label pour afficher le texte
label_message = tk.Label(fenetre, text=message)
label_message.pack(pady=20)

# Créer un widget Bouton pour fermer la fenêtre et continuer le code
bouton_continuer = tk.Button(fenetre, text="Continuer", command=fenetre.destroy)
bouton_continuer.pack()

# Faire une pause dans l'exécution du code et afficher la fenêtre
fenetre.mainloop()


def form(date_str_list):

    # Attendre jusqu'à 10 secondes pour que l'élément "date_element" soit visible
    date_element = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.ID, "app_date"))
    )
    print("extraction réuissie", date_str_list)
    date_str = date_str_list[0]
    date_list = date_str.split("-")
    transformed_date_str = f"{date_list[2]}-{date_list[1]}-{date_list[0]}"
    script = "document.getElementById('app_date').value = '{}'".format(transformed_date_str)
    driver.execute_script(script)


    # Attendre que l'élément "app_date" soit cliquable
    date_input = WebDriverWait(driver, 60).until(EC.element_to_be_clickable((By.ID, "app_date")))

    # Cliquer sur l'élément "app_date" pour afficher le calendrier
    ActionChains(driver).move_to_element(date_input).click().perform()
    print("click sur le clendrier")

    ###fermer le calendrier 
    close_calendar = WebDriverWait(driver, 60).until(EC.element_to_be_clickable((By.ID, "first_name")))
    ActionChains(driver).move_to_element(close_calendar).click().perform()
    ##chercher si le choix d'heure est disponible 
    # attendre jusqu'à 60 secondes que la liste déroulante avec l'identifiant "app_time" soit affichée
    app_time = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, 'app_time')))

    # sélectionner l'élément de liste déroulante par son identifiant "app_time"
    dropdown = Select(app_time)
    print("selection du slot ")
    # sélectionner la première option de la liste déroulante par son index (première option = index 0)
    dropdown.select_by_index(1)

    # attendre jusqu'à 60 secondes que la liste déroulante avec l'identifiant "VisaTypeId" soit affichée
    VisaTypeId = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, 'VisaTypeId')))

    # sélectionner l'élément de liste déroulante par son identifiant "app_time"
    VisaTypeId_slot = Select(VisaTypeId)

    # sélectionner la première option de la liste déroulante par son index (première option = index 1 qui visa tourism /index 2 Business/
    # index 3 Students / index 4 transit / 5 sport/6 medical / 7 family / 8 mission
                                            
    VisaTypeId_slot.select_by_index(1)
    print("selection du slot 1 ")




    #remplir les champs de coordonnées

    # Attendre jusqu'à 10 secondes pour que le champ "firstname" soit visible
    firstname_field = WebDriverWait(driver, 60).until(
        EC.visibility_of_element_located((By.ID, "first_name"))
    )

    # Remplir le champ "firstname" avec la valeur "karm"
    firstname_field.send_keys("mebarek")

    # Attendre jusqu'à 10 secondes pour que le champ "last_name" soit visible
    last_name_filed = WebDriverWait(driver, 60).until(
        EC.visibility_of_element_located((By.ID, "last_name"))
    )

    # Remplir le champ "firstname" avec la valeur "karm"
    last_name_filed.send_keys("selam")
        
    # Attendre que l'élément "app_birthdate" soit cliquable
    birthdate = WebDriverWait(driver, 60).until(EC.visibility_of_all_elements_located((By.ID, "dateOfBirth")))

    script = "document.getElementById('dateOfBirth').value = '{}'".format("1999-06-03")
    driver.execute_script(script)






    # attendre jusqu'à 60 secondes qu'on puisse mette le numero passport 
    nationalityId = WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, 'passport_no')))
    nationalityId.send_keys("585685944")
   
    # Attendre jusqu'à 10 secondes pour que le champ "pptIssueDate" soit visible
    pptIssueDate = WebDriverWait(driver, 60).until(
        EC.visibility_of_element_located((By.ID, "pptIssueDate"))
    )
    script = "document.getElementById('pptIssueDate').value = '{}'".format("2016-06-03")

    driver.execute_script(script)



    # Attendre que l'élément "pptIssueDate" soit cliquable
    pptExpiryDate = WebDriverWait(driver, 10).until(EC.visibility_of_all_elements_located((By.ID, "pptExpiryDate")))

    script = "document.getElementById('pptExpiryDate').value = '{}'".format("2025-06-03")
    driver.execute_script(script)
    # Attendre jusqu'à 10 secondes pour que le champ "passport_no" soit visible
    passport_no = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.ID, "pptIssuePalace"))
    )

    # Remplir le champ "firstname" avec la valeur "karm"
    passport_no.send_keys("TIZI RACHED")




    # Création de la fenêtre principale
    root = tk.Tk()

    # Fonction appelée lors du clic sur le bouton "Suivant"
    def on_next_click():
        # Affiche un message de confirmation
        messagebox.showinfo("Captcha", "Merci de remplir le champs captcha manuellment sur le formlaire BLS !")

    on_next_click()

    # Boucle principale de la fenêtre
    root.mainloop()





chrono = 0

while True:
        
        
    try:
        script_element = WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.XPATH, "/html/body/div[1]/section[1]/div/div[4]/script")))
        # Continuer le script en manipulant l'élément récupéré

    except TimeoutException:
        print("L'élément n'a pas été trouvé dans les 30 secondes. Rafraîchissement de la page...")
        driver.refresh()
        continue
    # Extraire le contenu de la balise script
    script_text = script_element.get_attribute("innerHTML")
    print("Début de script")
    texte = 'var available_dates = ["28-02-2023"];'
    # Vérifier que la variable "available_dates" est présente dans le contenu de la balise script
    match = re.search(r"var available_dates = (\[.*?\]);", texte)
    if match:
        # Extraire la valeur de la variable "available_dates"
        available_dates = match.group(1)
        # Imprimer la valeur de la variable "available_dates"
        print("extraction réussie : "+available_dates)
        # remove unnecessary characters from the string
        date_str_list = eval(available_dates)

        if len(date_str_list)== 0:
            print("date non trouvé !!! on rafraichie la page ")
            time.sleep(5)
            driver.refresh()
        else:
            print("date trouvé") 
            form(date_str_list)
            print("apres la fonction form")
            break
    else:
        # La variable "available_dates" n'est pas présente dans le contenu de la balise script
        print("La variable 'available_dates' n'est pas présente dans la balise script.")
        print("on refresh")
        print("chrono"+str(chrono))
        
        driver.refresh()
        time.sleep(10)
            
        

           
                

            

                 




