from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.service import Service
from webdriver_manager.firefox import GeckoDriverManager
import time
import re
import datetime

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
import tkinter as tk
from tkinter import simpledialog
from selenium.common.exceptions import TimeoutException
from tkinter import messagebox

#prise de coordonnées






#page de rdv script 
driver = webdriver.Firefox(service=Service(executable_path=GeckoDriverManager().install()))



driver.get("file:///C:/Users/zine-/Downloads/YANIS/Nouveau%20dossier%20(3)/Algeria%20BLS%20Spain%20Visa_%20Spain%20Visa%20for%20Algeria%20How%20to%20Book%20Your%20Appointment%20for%20BLS%20VAC.html")

import smtplib



def sendmail():

    # Paramètres du serveur SMTP d'Outlook
    serveur_smtp = 'smtp.office365.com'
    port_smtp = 587

    # Informations de connexion
    adresse_email = 'yanis.selam99@outlook.fr'
    mot_de_passe = '361999.Badi99'

    # Informations de l'e-mail
    destinataire = 'badi361999@gmail.com'
    sujet = 'RDV BLS Disponible '
    texte = 'RDV BLS Disponible check le site'

    # Connexion au serveur SMTP
    connexion_smtp = smtplib.SMTP(serveur_smtp, port_smtp)
    connexion_smtp.starttls() # Sécurisation de la connexion
    connexion_smtp.login(adresse_email, mot_de_passe)

    # Création de l'e-mail
    message = 'Subject: {}\n\n{}'.format(sujet, texte)

    # Envoi de l'e-mail
    connexion_smtp.sendmail(adresse_email, destinataire, message)

    # Déconnexion du serveur SMTP
    connexion_smtp.quit()
    print("mail envoyé")



# Créer une fenêtre tkinter
fenetre = tk.Tk()

# Définir les dimensions de la fenêtre
fenetre.geometry("300x200")

# Définir le texte à afficher dans la fenêtre
message = "Cliquez sur le bouton pour continuer."

# Créer un widget Label pour afficher le texte
label_message = tk.Label(fenetre, text=message)
label_message.pack(pady=20)

# Créer un widget Bouton pour fermer la fenêtre et continuer le code
bouton_continuer = tk.Button(fenetre, text="Continuer", command=fenetre.destroy)
bouton_continuer.pack()

# Faire une pause dans l'exécution du code et afficher la fenêtre
fenetre.mainloop()


Search_RDV = WebDriverWait(driver, 60).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="alg_app_first"]/section[1]/div/div/h2')))

while(True):
    try:
        # Attendre que la page soit complètement chargée
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
            # Récupérer le contenu de la page web
        page_content = driver.page_source

        # Vérifier la présence d'un mot spécifique
        if "Appointment dates are not available!" in page_content:
            print("Le mot recherché est présent sur la page.")
            time.sleep(5)
            driver.refresh()
            continue
        else:
            print("Le mot recherché n'est pas présent sur la page.")
            sendmail()
            break

    except TimeoutException:
        print("L'élément n'a pas été trouvé dans les 10 secondes. Rafraîchissement de la page...")
        driver.refresh()
        

    


