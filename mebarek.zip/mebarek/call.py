import os
from twilio.rest import Client


# Find your Account SID and Auth Token at twilio.com/console
# and set the environment variables. See http://twil.io/secure
account_sid = os.environ['AC5d3985b1f22377b659104f31a5323ba7']
auth_token = os.environ['cad68979e9572278402dbd91250f008d']
client = Client(account_sid, auth_token)

message = client.messages \
    .create(
         body='This is the ship that made the Kessel Run in fourteen parsecs?',
         from_='+15675295304',
         to='+33782735171'
     )

print(message.sid)