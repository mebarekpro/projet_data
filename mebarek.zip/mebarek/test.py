
import smtplib



def sendmail():

    # Paramètres du serveur SMTP d'Outlook
    serveur_smtp = 'smtp.office365.com'
    port_smtp = 587

    # Informations de connexion
    adresse_email = 'yanis.selam99@outlook.fr'
    mot_de_passe = '361999.Badi99'

    # Informations de l'e-mail
    destinataire = 'badi361999@gmail.com'
    sujet = 'RDV BLS Disponible '
    texte = 'RDV BLS Disponible check le site'

    # Connexion au serveur SMTP
    connexion_smtp = smtplib.SMTP(serveur_smtp, port_smtp)
    connexion_smtp.starttls() # Sécurisation de la connexion
    connexion_smtp.login(adresse_email, mot_de_passe)

    # Création de l'e-mail
    message = 'Subject: {}\n\n{}'.format(sujet, texte)

    # Envoi de l'e-mail
    connexion_smtp.sendmail(adresse_email, destinataire, message)

    # Déconnexion du serveur SMTP
    connexion_smtp.quit()

